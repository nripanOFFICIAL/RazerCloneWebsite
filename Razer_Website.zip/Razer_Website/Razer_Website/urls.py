# """
# URL configuration for Razer_Website project.

# The `urlpatterns` list routes URLs to views. For more information please see:
#     https://docs.djangoproject.com/en/5.2/topics/http/urls/
# Examples:
# Function views
#     1. Add an import:  from my_app import views
#     2. Add a URL to urlpatterns:  path('', views.home, name='home')
# Class-based views
#     1. Add an import:  from other_app.views import Home
#     2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
# Including another URLconf
#     1. Import the include() function: from django.urls import include, path
#     2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
# """
from django.urls import path
from index.views import index
from login.views import loginPage,login_form,logout
from about.views import about
from contact.views import contact
from signup.views import signup,signup_form
from userPage.views import userPage
from adminPage.views import adminPage
from employee.views import employee_table,employee,employeeAdd,showEmployee,deleteEmployee,editEmployee_function,addEmployee,edit_page

urlpatterns = [
    path('',index,name='index'),

    path('about/',about,name='about'),

    path('contact/',contact,name='contact'),
    
    path('edit_page/',edit_page,name='edit_page'),

    
    path('loginPage/',loginPage,name='loginPage'),
    path('logout/',logout,name='logout'),
    path('login_form/',login_form,name='login_form'),

    path('signup/',signup,name='signup'),
    path('signup_form/',signup_form,name='signup_form'),

    path('userPage/',userPage,name='userPage'),
    path('adminPage/',adminPage,name='adminPage'),


    path('employee_table/',employee_table,name='employee_table'),

    path('employee/',employee,name='employee'),

    path('employeeAdd/',employeeAdd,name='employeeAdd'),
    path('addEmployee/',addEmployee,name='addEmployee'),

    path('deleteEmployee/<int:pk>',deleteEmployee,name='deleteEmployee'),

    path('showEmployee/',showEmployee,name='showEmployee'),

    path('editEmployee_function/<int:pk>',editEmployee_function,name='editEmployee_function'),
    


]
