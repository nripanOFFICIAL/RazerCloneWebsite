from django.db import models

# Create your models here.
class employee_table(models.Model):
    fullname=models.CharField(max_length=20)
    age=models.IntegerField()
    gender=models.CharField(max_length=20)
    email=models.EmailField()
    designation=models.CharField(max_length=30)
    upload=models.ImageField(upload_to='image/')
    phno=models.CharField(max_length=30)