# Create your views here.
from django.shortcuts import render,redirect
from employee.models import employee_table
# Create your views here.
def employee(request):
    return render (request,'employee.html')

def employeeAdd(request):
    return render (request,'employeeAdd.html')

# def employeeList(request):
#     return render (request,'employeeList.html')

def addEmployee(request):
    if request.method=='POST':
        fullname=request.POST['fullname']
        age=request.POST['age']
        gender=request.POST['gender']
        email=request.POST['email']
        designation=request.POST['designation']
        image=request.FILES.get('photo')
        p_phno=request.POST['phno']
        ptr=employee_table(fullname=fullname,age=age,gender=gender,email=email,designation=designation,upload=image,phno=p_phno)
        ptr.save()
        return redirect('showEmployee')
    
    
def showEmployee(request):
    ptr=employee_table.objects.all()
    return render(request,'employeeList.html',{'key':ptr})

def editEmployee_function(request,pk):
    if request.method=='POST':
        profile=employee_table.object.get(id=pk)
        profile.fullname=request.POST['fullname']
        profile.age=request.POST['age']
        profile.gender=request.POST['gender']
        profile.email=request.POST['email']
        profile.designation=request.POST['designation']
        profile.phno=request.POST['phno']
        profile.save()
        return redirect('showEmployee')
    
def deleteEmployee(request,pk):
    dlt=employee_table.objects.get(id=pk)
    dlt.delete()
    return redirect('showEmployee')

def edit_page(request):
    return render(request,'employeeEdit.html')

