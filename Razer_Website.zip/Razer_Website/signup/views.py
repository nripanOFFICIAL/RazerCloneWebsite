from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User

# Create your views here.
def signup(request):
    return render (request,'signup.html')

def signup_form(request):
    if request.method=='POST':
        firstname=request.POST['firstname']
        lastname=request.POST['lastname']
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
        confirm_password=request.POST['confirm_password']
        if password==confirm_password:
            if User.objects.filter(username=username).exists():
                messages.info(request,'username already exists:)')
                return redirect('loginPage')
            else:
                user=User.objects.create_user(first_name=firstname,last_name=lastname,email=email,username=username,password=password)
                user.save()
    else:
        messages.info(request,'password not matching:(')
        return redirect('signup')
    return redirect('index')